package Paging;

import java.util.ArrayList;

public class LFU implements Algorithm {

	@Override
	public Integer pageReferenced(int page, ArrayList<Page> disk, ArrayList<Page> memory) {
		// TODO Auto-generated method stub
		return null;
	}

}
