package Swapping;

public interface Swap {
	public boolean swap(Process process, Memory memory);
}
